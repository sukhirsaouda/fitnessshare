# customerFeedbackPlugin ![](https://api.travis-ci.org/BuildFire/customerFeedbackPlugin.svg)


### How to run test cases
- npm install
- karma start